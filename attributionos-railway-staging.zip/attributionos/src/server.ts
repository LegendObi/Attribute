import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { PrismaClient } from '@prisma/client';
import { randomBytes, createHash, createCipheriv, createDecipheriv, timingSafeEqual, scryptSync } from 'node:crypto';
import { z } from 'zod';
import path from 'node:path';

const db = new PrismaClient();
const app = express();
app.use(helmet({contentSecurityPolicy:false})); app.use(express.json()); app.use(cookieParser());
const base = process.env.BASE_URL || 'http://localhost:3000';
const keyHex = process.env.TOKEN_ENCRYPTION_KEY || '';
if(!/^[a-fA-F0-9]{64}$/.test(keyHex)) throw new Error('TOKEN_ENCRYPTION_KEY must be 32 bytes in hex');
const key=Buffer.from(keyHex,'hex');
function encrypt(v:string){const iv=randomBytes(12), c=createCipheriv('aes-256-gcm',key,iv);const data=Buffer.concat([c.update(v,'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),data]).toString('base64');}
function decrypt(v:string){const b=Buffer.from(v,'base64');const d=createDecipheriv('aes-256-gcm',key,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));return Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8');}
const sha=(s:string)=>createHash('sha256').update(s).digest('hex');
const safe=(x:any)=>x instanceof Error?x.message:String(x);
const providers=['meta','tiktok','google'] as const;
type Provider=typeof providers[number];
const validProvider=(s:string):s is Provider=>providers.includes(s as Provider);

// Cookie-backed sessions, hashed at rest. Secure cookie requires HTTPS in production.
const passwordHash=(password:string,salt=randomBytes(16).toString('hex'))=>salt+':'+scryptSync(password,salt,64).toString('hex');
const passwordValid=(password:string,stored:string)=>{const [salt,hash]=stored.split(':');if(!salt||!hash)return false;const actual=scryptSync(password,salt,64), expected=Buffer.from(hash,'hex');return actual.length===expected.length&&timingSafeEqual(actual,expected);};
async function identity(req:express.Request){
 const token=req.cookies.aos_session;
 if(typeof token!=='string')throw new Error('Authentication required');
 const session=await db.session.findUnique({where:{tokenHash:sha(token)}});
 if(!session||session.expiresAt<new Date())throw new Error('Session expired');
 const membership=await db.membership.findFirst({where:{userId:session.userId}});
 if(!membership)throw new Error('Workspace membership required');
 return {userId:session.userId,orgId:membership.organizationId,role:membership.role};
}
function setSession(res:express.Response,token:string){res.cookie('aos_session',token,{httpOnly:true,secure:base.startsWith('https:'),sameSite:'lax',maxAge:7*86400000,path:'/'});}
async function createSession(res:express.Response,userId:string){const token=randomBytes(32).toString('base64url');await db.session.create({data:{userId,tokenHash:sha(token),expiresAt:new Date(Date.now()+7*86400000)}});setSession(res,token);}
const credentials=z.object({email:z.string().email().max(254),password:z.string().min(12).max(256)});
app.post('/api/auth/register',async(req,res)=>{try{const {email,password}=credentials.parse(req.body);const normalized=email.toLowerCase();if(await db.user.findUnique({where:{email:normalized}}))return res.status(409).json({error:'Account already exists'});const user=await db.user.create({data:{email:normalized,passwordHash:passwordHash(password),memberships:{create:{role:'owner',organization:{create:{name:normalized.split('@')[0]+" Workspace"}}}}}});await createSession(res,user.id);res.json({ok:true});}catch(e){res.status(400).json({error:safe(e)});}});
app.post('/api/auth/login',async(req,res)=>{try{const {email,password}=credentials.parse(req.body);const user=await db.user.findUnique({where:{email:email.toLowerCase()}});if(!user?.passwordHash||!passwordValid(password,user.passwordHash))return res.status(401).json({error:'Invalid credentials'});await createSession(res,user.id);res.json({ok:true});}catch(e){res.status(400).json({error:safe(e)});}});
app.post('/api/auth/logout',async(req,res)=>{const token=req.cookies.aos_session;if(typeof token==='string')await db.session.deleteMany({where:{tokenHash:sha(token)}});res.clearCookie('aos_session',{path:'/'});res.json({ok:true});});
app.get('/api/auth/me',async(req,res)=>{try{const a=await identity(req);res.json({authenticated:true,...a});}catch{res.status(401).json({authenticated:false});}});
function config(p:Provider){
 const m={meta:['META_APP_ID','META_APP_SECRET'],tiktok:['TIKTOK_APP_ID','TIKTOK_SECRET'],google:['GOOGLE_CLIENT_ID','GOOGLE_CLIENT_SECRET']}[p];
 const id=process.env[m[0]],secret=process.env[m[1]];
 if(!id||!secret) throw new Error(`${p} app credentials not configured`);
 return {id,secret,redirect:`${base}/api/oauth/${p}/callback`};
}
function authorization(p:Provider,state:string,verifier:string){
 const c=config(p);
 if(p==='meta'){const u=new URL(`https://www.facebook.com/${process.env.META_GRAPH_VERSION||'v22.0'}/dialog/oauth`);u.search=new URLSearchParams({client_id:c.id,redirect_uri:c.redirect,state,response_type:'code',scope:'ads_read,business_management'}).toString();return u.toString();}
 if(p==='google'){const u=new URL('https://accounts.google.com/o/oauth2/v2/auth');u.search=new URLSearchParams({client_id:c.id,redirect_uri:c.redirect,response_type:'code',scope:'https://www.googleapis.com/auth/analytics.readonly https://www.googleapis.com/auth/adwords',access_type:'offline',prompt:'consent',state,code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256'}).toString();return u.toString();}
 // TikTok for Business Marketing API OAuth: configure the approved Marketing API app, not Login Kit.
 const u=new URL(process.env.TIKTOK_AUTH_URL||'https://business-api.tiktok.com/portal/auth');u.search=new URLSearchParams({app_id:c.id,state,redirect_uri:c.redirect}).toString();return u.toString();
}
async function postJson(url:string,body:unknown){const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const j:any=await r.json();if(!r.ok)throw new Error(`Token exchange HTTP ${r.status}`);return j;}
async function exchange(p:Provider,code:string,verifier:string){const c=config(p);
 if(p==='meta'){
  const u=new URL(`https://graph.facebook.com/${process.env.META_GRAPH_VERSION||'v22.0'}/oauth/access_token`);u.search=new URLSearchParams({client_id:c.id,client_secret:c.secret,redirect_uri:c.redirect,code}).toString();const r=await fetch(u);const j:any=await r.json();if(!r.ok||!j.access_token)throw new Error('Meta OAuth exchange failed');
  // Extend short-lived user token when possible.
  const long=new URL(`https://graph.facebook.com/${process.env.META_GRAPH_VERSION||'v22.0'}/oauth/access_token`);long.search=new URLSearchParams({grant_type:'fb_exchange_token',client_id:c.id,client_secret:c.secret,fb_exchange_token:j.access_token}).toString();const lr=await fetch(long);const lj:any=await lr.json();return {access:lr.ok&&lj.access_token?lj.access_token:j.access_token,refresh:null,expires:lj.expires_in||j.expires_in||null};
 }
 if(p==='google'){
  const form=new URLSearchParams({code,client_id:c.id,client_secret:c.secret,redirect_uri:c.redirect,grant_type:'authorization_code',code_verifier:verifier});const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:form});const j:any=await r.json();if(!r.ok||!j.access_token)throw new Error('Google OAuth exchange failed');return {access:j.access_token as string,refresh:(j.refresh_token as string | undefined) || null,expires:j.expires_in||null};
 }
 const j:any=await postJson(process.env.TIKTOK_TOKEN_URL||'https://business-api.tiktok.com/open_api/v1.3/oauth2/access_token/',{app_id:c.id,secret:c.secret,auth_code:code});if(j.code!==0||!j.data?.access_token)throw new Error('TikTok Business OAuth exchange failed');return {access:j.data.access_token as string,refresh:j.data.refresh_token||null,expires:j.data.expires_in||null};
}
app.get('/api/config',async(_req,res)=>{res.json(Object.fromEntries(providers.map(p=>[p,!!(process.env[{meta:'META_APP_ID',tiktok:'TIKTOK_APP_ID',google:'GOOGLE_CLIENT_ID'}[p]])])));});
app.get('/api/connections',async(req,res)=>{try{const a=await identity(req);const rows=await db.connection.findMany({where:{organizationId:a.orgId},select:{id:true,provider:true,status:true,createdAt:true,expiresAt:true,accounts:{select:{externalId:true,name:true}}}});res.json(rows);}catch(e){res.status(401).json({error:safe(e)});}});
app.get('/api/oauth/:provider/start',async(req,res)=>{try{
 const p=req.params.provider;if(!validProvider(p))return res.status(404).end();const a=await identity(req);
 const state=randomBytes(32).toString('base64url'),verifier=randomBytes(48).toString('base64url');
 await db.oAuthState.create({data:{stateHash:sha(state),organizationId:a.orgId,userId:a.userId,provider:p,codeVerifier:verifier,expiresAt:new Date(Date.now()+10*60_000)}});
 res.cookie('oauth_state',state,{httpOnly:true,secure:base.startsWith('https:'),sameSite:'lax',maxAge:600000,path:`/api/oauth/${p}/callback`});res.redirect(authorization(p,state,verifier));
 }catch(e){res.status(400).send(safe(e));}});
app.get('/api/oauth/:provider/callback',async(req,res)=>{try{
 const p=req.params.provider;if(!validProvider(p))return res.status(404).end();
 const {state,code,error}=z.object({state:z.string().optional(),code:z.string().optional(),auth_code:z.string().optional(),error:z.string().optional()}).passthrough().parse(req.query);
 if(error)throw new Error('Provider denied authorization');const actualCode=code||(typeof req.query.auth_code==='string'?req.query.auth_code:undefined);
 if(!state||!actualCode||typeof req.cookies.oauth_state!=='string')throw new Error('Missing OAuth code or state');
 const expected=Buffer.from(sha(req.cookies.oauth_state),'hex'),received=Buffer.from(sha(state),'hex');if(!timingSafeEqual(expected,received))throw new Error('OAuth state mismatch');
 const record=await db.oAuthState.findUnique({where:{stateHash:sha(state)}});
 if(!record||record.provider!==p||record.expiresAt<new Date())throw new Error('Expired or invalid OAuth request');
 const a=await identity(req);if(record.organizationId!==a.orgId||record.userId!==a.userId)throw new Error('OAuth user changed');
 // Atomic one-time consumption before token exchange prevents callback replay.
 const consumed=await db.oAuthState.deleteMany({where:{id:record.id,stateHash:sha(state)}});if(consumed.count!==1)throw new Error('OAuth state already consumed');
 const tokens=await exchange(p,actualCode,record.codeVerifier||'');
 await db.connection.create({data:{organizationId:a.orgId,provider:p,encryptedAccessToken:encrypt(tokens.access),encryptedRefreshToken:tokens.refresh?encrypt(tokens.refresh):null,expiresAt:tokens.expires?new Date(Date.now()+Number(tokens.expires)*1000):null}});
 res.clearCookie('oauth_state',{path:`/api/oauth/${p}/callback`});res.redirect('/?connected='+p);
 }catch(e){res.redirect('/?error='+encodeURIComponent(safe(e)));}});
app.delete('/api/connections/:id',async(req,res)=>{try{const a=await identity(req);const row=await db.connection.findFirst({where:{id:req.params.id,organizationId:a.orgId}});if(!row)return res.status(404).end();await db.connection.delete({where:{id:row.id}});res.json({ok:true,warning:'Local credentials deleted; revoke provider access separately.'});}catch(e){res.status(401).json({error:safe(e)});}});
// Account discovery. Provider errors are returned without leaking credentials.
app.post('/api/connections/:id/discover',async(req,res)=>{try{const a=await identity(req);const conn=await db.connection.findFirst({where:{id:req.params.id,organizationId:a.orgId}});if(!conn)return res.status(404).json({error:'Connection not found'});const token=decrypt(conn.encryptedAccessToken);let accounts:{id:string,name:string,currency?:string,timezone?:string}[]=[];
 if(conn.provider==='meta'){let next:string|undefined=`https://graph.facebook.com/${process.env.META_GRAPH_VERSION||'v22.0'}/me/adaccounts?fields=id,name,currency,timezone_name&limit=100`;for(let i=0;next&&i<20;i++){const r=await fetch(next,{headers:{authorization:`Bearer ${token}`}});const j:any=await r.json();if(!r.ok)throw new Error('Meta account discovery failed');accounts.push(...(j.data||[]).map((x:any)=>({id:x.id,name:x.name,currency:x.currency,timezone:x.timezone_name})));next=j.paging?.next;}}
 else if(conn.provider==='tiktok'){const url=new URL('https://business-api.tiktok.com/open_api/v1.3/oauth2/advertiser/get/');url.searchParams.set('app_id',config('tiktok').id);url.searchParams.set('secret',config('tiktok').secret);const r=await fetch(url,{headers:{'Access-Token':token}});const j:any=await r.json();if(!r.ok||j.code!==0)throw new Error('TikTok advertiser discovery failed');accounts=(j.data?.list||[]).map((x:any)=>({id:String(x.advertiser_id),name:x.advertiser_name||String(x.advertiser_id)}));}
 else {const r=await fetch('https://googleads.googleapis.com/v19/customers:listAccessibleCustomers',{headers:{authorization:`Bearer ${token}`,'developer-token':process.env.GOOGLE_ADS_DEVELOPER_TOKEN||''}});const j:any=await r.json();if(!r.ok)throw new Error('Google Ads account discovery failed; check developer token and API version');accounts=(j.resourceNames||[]).map((x:string)=>({id:x.split('/').pop()!,name:x}));}
 for(const x of accounts){await db.adAccount.upsert({where:{organizationId_provider_externalId:{organizationId:a.orgId,provider:conn.provider,externalId:x.id}},update:{name:x.name,currency:x.currency,timezone:x.timezone},create:{organizationId:a.orgId,connectionId:conn.id,provider:conn.provider,externalId:x.id,name:x.name,currency:x.currency,timezone:x.timezone}});}
 res.json({count:accounts.length,accounts});}catch(e){res.status(400).json({error:safe(e)});}});
// First-party event ingestion with tenant-bound API key, not arbitrary workspace IDs.
const eventSchema=z.object({eventId:z.string().min(1).max(150),occurredAt:z.string().datetime(),eventType:z.string().min(1).max(80),value:z.number().finite().nonnegative().default(0),currency:z.string().length(3).default('USD'),visitorId:z.string().max(150).optional(),sessionId:z.string().max(150).optional(),source:z.string().max(150).optional(),medium:z.string().max(150).optional(),campaign:z.string().max(250).optional(),landingPage:z.string().max(2000).optional()});
app.post('/api/events',async(req,res)=>{try{const a=await identity(req);const event=eventSchema.parse(req.body);const row=await db.conversionEvent.upsert({where:{organizationId_eventId:{organizationId:a.orgId,eventId:event.eventId}},update:{},create:{...event,occurredAt:new Date(event.occurredAt),organizationId:a.orgId}});res.status(201).json({id:row.id});}catch(e){res.status(400).json({error:safe(e)});}});
app.get('/api/reports/attribution',async(req,res)=>{try{const a=await identity(req);const model=z.enum(['first_touch','last_touch','linear']).parse(req.query.model||'last_touch');const days=Math.min(365,Math.max(1,Number(req.query.days)||30));const rows=await db.conversionEvent.findMany({where:{organizationId:a.orgId,occurredAt:{gte:new Date(Date.now()-days*86400000)}},orderBy:{occurredAt:'asc'},take:10000});const paths=new Map<string,typeof rows>();for(const e of rows){const id=e.visitorId||e.sessionId||e.id;paths.set(id,[...(paths.get(id)||[]),e]);}const byChannel=new Map<string,{conversions:number,revenue:number}>();for(const events of paths.values()){const touches=events.filter(e=>e.source||e.medium);for(const conversion of events.filter(e=>['purchase','lead','conversion'].includes(e.eventType))){const eligible=touches.filter(t=>t.occurredAt<=conversion.occurredAt);if(!eligible.length)continue;const selected=model==='first_touch'?[eligible[0]]:model==='last_touch'?[eligible[eligible.length-1]]:eligible;const weight=1/selected.length;for(const t of selected){const channel=[t.source||'direct',t.medium||'none'].join(' / ');const v=byChannel.get(channel)||{conversions:0,revenue:0};v.conversions+=weight;v.revenue+=Number(conversion.value)*weight;byChannel.set(channel,v);}}}res.json({model,days,eventsAnalyzed:rows.length,channels:[...byChannel].map(([channel,v])=>({channel,...v}))});}catch(e){res.status(400).json({error:safe(e)});}});
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'attributionos'}));
app.get('/api/ready',async(_req,res)=>{try{await db.$queryRaw`SELECT 1`;res.json({ok:true,database:'reachable'});}catch{res.status(503).json({ok:false,database:'unavailable'});}});
app.use(express.static(path.join(process.cwd(),'public')));
app.listen(Number(process.env.PORT||3000),()=>console.log(`AttributionOS running at ${base}`));
