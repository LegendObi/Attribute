# AttributionOS: Railway deployment runbook

## 0. Important launch boundary

This is a **pre-production prototype**, not yet a safe public SaaS. Do not invite customers or connect sensitive production ad accounts until authentication hardening, email verification, CSRF protection, rate limiting, account recovery, OAuth provider testing, privacy/data deletion, and security review are complete. Deploy as a private/staging service first. Do not paste secrets into ChatGPT, GitHub, or Railway build logs.

## 1. Push this source to a private GitHub repository

Unzip the project, open a terminal in `attributionos/`, then:

```bash
git init
git add .
git commit -m "Initial standalone AttributionOS Railway staging deployment"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-PRIVATE-REPO.git
git push -u origin main
```

Create the private GitHub repo first. `.env` and `.env.*` (except `.env.example`) are ignored by `.gitignore`; confirm with `git status` before pushing.

## 2. Create Railway project

1. Sign in at https://railway.com/ and select **New Project**.
2. Add **PostgreSQL** to the project.
3. Add a **GitHub Repo** service pointing to your private AttributionOS repository.
4. The repository `railway.json` selects the Dockerfile build and the `/api/ready` database readiness check.
5. In the web service Variables tab set `DATABASE_URL` to the Railway PostgreSQL `DATABASE_URL` reference using Railway's variable reference UI, rather than manually copying credentials.
6. Set `TOKEN_ENCRYPTION_KEY` to a fresh 64-character hexadecimal value generated locally with `openssl rand -hex 32`. Keep a secure backup. Losing this key makes previously encrypted provider tokens unreadable.
7. Set `NODE_ENV=production` and `DEV_AUTH=false`.
8. Add `BASE_URL` **after** generating a public Railway service domain; use its full `https://...up.railway.app` origin without trailing slash.
9. Deploy. Railway supplies `PORT`; do not hard-code an external port.

## 3. Initialize database

After the Postgres service is running, run from a Railway environment that has access to `DATABASE_URL`:

```bash
npx prisma db push
```

For production, replace `db push` with reviewed, versioned Prisma migrations (`prisma migrate deploy`). Do not run schema changes blindly on customer data. Recheck `/api/ready` after initializing the schema.

## 4. Configure developer apps (only those already approved)

Set secrets in Railway **service Variables**, never in `VITE_*`, `NEXT_PUBLIC_*`, or browser code:

- Meta: `META_APP_ID`, `META_APP_SECRET`, `META_GRAPH_VERSION` (currently supported Graph API version)
- TikTok for Business: `TIKTOK_APP_ID`, `TIKTOK_SECRET`, `TIKTOK_AUTH_URL`, `TIKTOK_TOKEN_URL` (validate against approved Business API documentation)
- Google: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_ADS_DEVELOPER_TOKEN`

Register exact redirect URIs (replace YOUR-RAILWAY-DOMAIN):

```text
https://YOUR-RAILWAY-DOMAIN/api/oauth/meta/callback
https://YOUR-RAILWAY-DOMAIN/api/oauth/tiktok/callback
https://YOUR-RAILWAY-DOMAIN/api/oauth/google/callback
```

The TikTok Business API authorization flow varies by approved app type and should be confirmed before testing. Google Ads additionally needs developer token approval; GA4 property discovery is not implemented. API version and app review requirements can change.

## 5. Staging verification

1. Confirm `/api/health` returns JSON and `/api/ready` confirms database reachability.
2. Verify sign-up/login/logout and cookie behavior with HTTPS.
3. Confirm the dashboard shows unconfigured providers rather than fake live data.
4. Confirm unauthorized requests to `/api/connections` are denied.
5. For each provider, test consent, callback state validation, token exchange, account discovery, disconnect and failure paths with dedicated test accounts.
6. Test user isolation between two organizations before customer onboarding.
7. Inspect Railway deploy logs for exceptions **without logging tokens**.

## 6. Still required before public launch

- Email verification and password reset; login rate limits and account lockout controls
- CSRF protections for state-changing endpoints and stronger multi-organization role enforcement
- Background workers and durable job queue; automatic Ads/GA4 ingestion and token refresh
- TikTok account discovery; GA4 property discovery; up-to-date Google Ads API version
- Data deletion, consent management, audit logs, backups, alerts and billing
- Tests for webhook signatures, provider pagination, deduplication, and attribution accuracy

No domain purchase is necessary for staging: Railway's generated `up.railway.app` domain works as a temporary HTTPS origin if the OAuth provider accepts it. A verified custom domain may be needed for public OAuth verification.
