# AttributionOS Connect — OAuth SaaS foundation

An independent TypeScript/Express/PostgreSQL integration dashboard for Meta Ads, TikTok for Business Marketing API, and Google Ads/GA4 OAuth.

## Quick start

1. Install Node.js 20+, Docker, and npm.
2. `cp .env.example .env`
3. Run `openssl rand -hex 32` and paste the result into `TOKEN_ENCRYPTION_KEY` in `.env`.
4. `docker compose up -d`
5. `npm install`
6. `npx prisma generate && npx prisma db push`
7. `npm run dev`
8. Open http://localhost:3000

Create an account using the dashboard (password minimum 12 characters). Authorization buttons remain disabled until you configure provider keys.

## Provider setup

### Meta
Create a Meta for Developers app with Facebook Login for Business / appropriate business login configuration and Marketing API access. Add `http://localhost:3000/api/oauth/meta/callback` for local testing where allowed; use a real HTTPS domain in production. Set `META_APP_ID`, `META_APP_SECRET`. Request `ads_read` and `business_management` as needed; obtain advanced access/review for external users. API version is configurable via `META_GRAPH_VERSION` and should be set to a currently supported version.

### TikTok
**Use TikTok for Business Marketing API developer access**, which is distinct from consumer TikTok Login Kit. Register an application and configure its authorization redirect according to the Business API onboarding instructions. Set `TIKTOK_APP_ID`, `TIKTOK_SECRET`, `TIKTOK_AUTH_URL`, and `TIKTOK_TOKEN_URL`. The authorization URL and callback code format can vary by approved business integration; verify with the current Business API documentation before going live. TikTok account discovery and refresh behavior are not yet implemented.

### Google
Create an external OAuth consent screen and a Web application OAuth client in Google Cloud. Enable Google Ads API and Google Analytics Data API. Add `http://localhost:3000/api/oauth/google/callback` to authorized redirect URIs (or your HTTPS domain). Set `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`. For Google Ads reporting also obtain and configure `GOOGLE_ADS_DEVELOPER_TOKEN` and required Ads API access. OAuth scope approval/verification may be needed.

## What is implemented
- Multi-tenant organization, membership, integration and account database models
- OAuth authorization initiation and callback for Meta, TikTok Business, and Google
- State cookie validation, short-lived server-side OAuth state and one-time consumption
- Google PKCE and offline access request
- Meta short-lived to long-lived token exchange attempt
- AES-256-GCM encrypted access/refresh tokens in PostgreSQL
- Connection status API and dashboard
- Organization-scoped connection deletion

## Not yet implemented — do not market as complete attribution software
- Production login/session middleware: `DEV_AUTH=true` only works outside `NODE_ENV=production`. **Production routes intentionally refuse authentication until a real verified session middleware is installed.**
- Provider account discovery, token refresh scheduling, API pagination and rate-limit handling
- TikTok provider-specific account approval / complete production verification
- Reporting ingestion workers, webhooks, event pipeline, identity matching, deduplication, attribution calculations, and reporting dashboard
- Provider-side token revocation, audit logs, secrets rotation, tenant-specific permissions, data retention/deletion, and security testing

## Production considerations
Use HTTPS and set `BASE_URL` to your public HTTPS origin. Configure approved redirect URIs exactly. Never expose app secrets in the frontend. Keep encryption keys in a secret manager. Rotate tokens and keys safely. Install a production session provider and enforce organization-level role checks. Add rate limits, monitoring, CSRF protections on mutating routes, and API request retries before launch. Current disconnect removes local stored credentials but does not revoke provider grants.

## Additional standalone application functionality
- Email/password registration and login using scrypt password hashes, server-side hashed sessions and HTTP-only cookies. **Email verification, password reset, rate limiting, MFA and security audit are still required before public production use.**
- Meta, TikTok Business and Google Ads account discovery endpoints (`POST /api/connections/:id/discover`). These require real provider authorization and have **not been verified with live accounts**. Google Ads API version must be checked against current supported versions.
- First-party authenticated conversion event intake (`POST /api/events`) with idempotent event IDs. This is not a public website tracking pixel; browser-side collection requires a separate secure collector.
- `GET /api/reports/attribution?model=last_touch&days=30` supports first-touch, last-touch and linear credit over recorded events. This is a basic directional model, not cross-device identity resolution or proven incremental attribution.
- Data models for sessions, events and sync logs.

### Security and production blockers
This repository is a **development foundation, not a production-complete SaaS**. It still needs email verification, account recovery, brute-force protection, CSRF mitigation, provider API version maintenance, refresh workers, durable ingestion queues, billing, operational monitoring, and third-party security review. OAuth callback session cookies may not work in every third-party browser flow and need browser testing. Never deploy publicly without hardening. Never send API secrets in chat; use your server secret manager.

### Verification status
The source code was generated in this environment. Dependency installation did not complete because package retrieval timed out, so compilation and end-to-end execution could not be verified. Run `npm install`, `npx prisma generate`, `npm run build` and test with a local PostgreSQL database before deployment.
